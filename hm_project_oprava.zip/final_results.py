import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import os
import json
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

# Silence warning
os.environ["LOKY_MAX_CPU_COUNT"] = "4"

# Load preprocessed dataset
df = pd.read_csv("hm_preprocessed.csv")

# Separate features and target (log-transformed price)
X = df.drop("price", axis=1)
y = df["price"]

# Split the dataset into training and testing sets (80/20 split)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Load best parameters from JSON files
with open('svr_params.json', 'r') as f:
    svr_params = json.load(f)
with open('decision_tree_params.json', 'r') as f:
    dt_params = json.load(f)
with open('random_forest_params.json', 'r') as f:
    rf_params = json.load(f)
with open('mlp_params.json', 'r') as f:
    mlp_params = json.load(f)
with open('xgboost_params.json', 'r') as f:
    xgb_params = json.load(f)
with open('knn_params.json', 'r') as f:
    knn_params = json.load(f)

# Create models with loaded parameters
models = {
    'SVR': SVR(**svr_params),
    'Decision Tree': DecisionTreeRegressor(random_state=42, **dt_params),
    'Random Forest': RandomForestRegressor(random_state=42, **rf_params),
    'MLP': MLPRegressor(random_state=42, **mlp_params),
    'XGBoost': XGBRegressor(random_state=42, **xgb_params),
    'kNN': KNeighborsRegressor(**knn_params)
}

# Initialize results storage
mae_vals, rmse_vals, mape_vals, best_params = [], [], [], []

# Perform GridSearchCV for each model
for model_name, model in models.items():
    print(f"Fitting {model_name}...")

    # Fit model on log-transformed prices
    model.fit(X_train, y_train)

    # Predict (still in log space)
    y_pred_log = model.predict(X_test)

    # Convert both predictions and true values back to original scale
    y_pred = np.expm1(y_pred_log)
    y_test_orig = np.expm1(y_test)

    # Compute metrics on original scale
    mae = mean_absolute_error(y_test_orig, y_pred)
    mse = mean_squared_error(y_test_orig, y_pred)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((y_test_orig - y_pred) / y_test_orig)) * 100

    # Store results
    mae_vals.append(mae)
    rmse_vals.append(rmse)
    mape_vals.append(mape)

# Convert results to DataFrame for easy visualization
results_df = pd.DataFrame({
    'Model': list(models.keys()),
    'MAE': mae_vals,
    'RMSE': rmse_vals,
    'MAPE (%)': mape_vals,
})

# Print results and save to CSV
print(results_df.sort_values('RMSE'))
results_df.to_csv('model_comparison_results.csv', index=False)

# Visualization: Bar plots for metrics
# Set plot style
sns.set(style="whitegrid")

# --- MAE Plot ---
plt.figure(figsize=(8, 6))
sns.barplot(x='Model', y='MAE', data=results_df, hue='Model', palette='Oranges_d', legend=False)
plt.title('MAE by Model')
plt.ylabel('MAE')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('mae_by_model.png')

# --- RMSE Plot ---
plt.figure(figsize=(8, 6))
sns.barplot(x='Model', y='RMSE', data=results_df, hue='Model', palette='Blues_d', legend=False)
plt.title('RMSE by Model')
plt.ylabel('RMSE')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('rmse_by_model.png')

# --- MAPE Plot ---
plt.figure(figsize=(8, 6))
sns.barplot(x='Model', y='MAPE (%)', data=results_df, hue='Model', palette='Greens_d', legend=False)
plt.title('MAPE by Model')
plt.ylabel('MAPE (%)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('mape_by_model.png')

# Visualization: Scatter plot for best model
# Find model with lowest RMSE
best_index = np.argmin(rmse_vals)
best_model_name = results_df.iloc[best_index]['Model']
best_model = models[best_model_name]
print(f"\nBest model (by RMSE): {best_model_name}")

# Get predictions and true values
best_pred_log = best_model.predict(X_test)
best_pred = np.expm1(best_pred_log)
best_true = np.expm1(y_test)

plt.figure(figsize=(8, 8))
plt.scatter(best_true, best_pred, alpha=0.4)
plt.plot([0, max(best_true)], [0, max(best_true)], 'r--')
plt.xlabel("Real Price")
plt.ylabel("Predicted Price")
plt.title(f"Pred vs Real – {best_model_name}")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{best_model_name.lower().replace(' ', '_')}_scatter.png")

# # Visualization: Boxplot of relative error by category
# Chosen categories
category_columns = ["outerwear", "dresses", "boots"]

df_viz = X_test.copy()
df_viz["RealPrice"] = best_true
df_viz["PredictedPrice"] = best_pred
df_viz["RelError"] = np.abs(df_viz["RealPrice"] - df_viz["PredictedPrice"]) / df_viz["RealPrice"]

for cat in category_columns:
    if cat in df_viz.columns:
        plt.figure(figsize=(6, 5))
        sns.boxplot(x=df_viz[cat], y=df_viz["RelError"])
        plt.title(f"Relative Error by category: {cat}")
        plt.xlabel(f"{cat} (0 = no, 1 = yes)")
        plt.ylabel("Relative Error")
        plt.ylim(0, 1)
        plt.tight_layout()
        plt.savefig(f"relative_error_by_{cat}.png")
plt.show()