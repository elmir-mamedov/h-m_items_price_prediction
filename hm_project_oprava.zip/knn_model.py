from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
import pandas as pd
import json

# Load preprocessed dataset
df = pd.read_csv("hm_preprocessed.csv")

# Separate target (log-transformed price) and features
target_column = "price"
X = df.drop(target_column, axis=1)
y = df[target_column]

# Split the dataset into training and testing sets (80/20 split)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize kNN Regressor
knn = KNeighborsRegressor()

# Define the parameter grid for GridSearchCV
knn_params = {
    "n_neighbors": [3, 5, 7],
    "weights": ["uniform", "distance"],
    "algorithm": ["auto", "ball_tree", "kd_tree", "brute"]
}

# Find best parameters using GridSearchCV
# Use MAE as scoring metric, because it is more suitable
# for non-linear models than R2
grid_search = GridSearchCV(
    knn,
    knn_params,
    scoring="neg_mean_absolute_error",
    cv=5,
    verbose=5,
    n_jobs=-1
)

print("Training model...")
grid_search.fit(X_train, y_train)

# Print best score and best parameters
print('Best parameters:', grid_search.best_params_)
print('Best MAE:', -grid_search.best_score_)    # Negate the score to get the actual MAE

# Save best parameters to json for later use
with open('knn_params.json', 'w') as f:
    json.dump(grid_search.best_params_, f)