import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neural_network import MLPRegressor

# Load preprocessed dataset
path = 'hm_preprocessed.csv'
data = pd.read_csv(path)

# Separate target (log-transformed price) and features
target_col = 'price'
X = data.drop(columns=[target_col])
y = data[target_col]

# Split the dataset into training and testing sets (80/20 split)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Define MLP Regressor
mlp = MLPRegressor(random_state=42, early_stopping=True)

# Define the parameter grid for GridSearchCV
param_grid = {
    'hidden_layer_sizes': [(50, 20, 20), (50, 50, 10), (60, 30, 30)],
    'activation': ['relu', 'tanh'],
    'solver': ['adam'],
    'alpha': [0.0001, 0.001],
    'learning_rate_init': [0.001],
    'max_iter': [500, 1000  ]
}


# Setup GridSearchCV (using only X_train/y_train)
# Use MAE as scoring metric, because it is more suitable
# for non-linear models than R2
grid_search = GridSearchCV(
    estimator=mlp,
    param_grid=param_grid,
    cv=5,
    scoring='neg_mean_absolute_error',
    n_jobs=-1,
    verbose=5
)

# Run grid search
print('Fitting grid search...')
grid_search.fit(X_train, y_train)

# Print best parameters and cross-validated score
print('\n=== Best Model ===')
print('Best parameters:', grid_search.best_params_)
print('Best MAE (cross-validated):', -grid_search.best_score_)  # Negate the score to get the actual MAE

import json

# Save best params to json for later use
with open('mlp_params.json', 'w') as f:
    json.dump(grid_search.best_params_, f)